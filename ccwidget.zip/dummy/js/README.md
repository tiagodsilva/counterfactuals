ization of counterfactuals

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save ccwidget
```
